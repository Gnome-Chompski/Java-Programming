import java.util.Iterator;
import java.util.NoSuchElementException;

//Dante Preda 2346605
//Bag implemented as a binary search tree

public class BSTBag<E extends Comparable<E>> implements Bag<E> {

    private Node<E> root;
    private int count;

    // Inner Class to hold the Counted Element
    private static class Node<E extends Comparable<E>> {
	protected CountedElement<E> element;
	protected Node<E> left, right;

	protected Node(E elem) {
	    this.element = new CountedElement<E>(elem);
	    left = null;
	    right = null;
	}
    }

    public BSTBag() {
	root = null;
	count = 0;
    }

    @Override
    public boolean isEmpty() {
	if (root == null) {
	    return true;
	} else {
	    return false;
	}
    }

    @Override
    public int size() {
	return count;
    }

    @Override
    public boolean contains(E tar) {
	Node<E> target = new Node<E>(tar);
	int direction = 1;
	Node<E> curr = root;
	while (curr != null) {

	    // Compare the element that is being counted usually the String
	    direction = target.element.getElement().compareTo(curr.element.getElement());

	    // Compare the element exists and there is more than 1, lazy
	    // deletion employed so there can be 0
	    if (direction == 0 && curr.element.getCount() > 0) {
		return true;
	    } else if (direction < 0) {
		curr = curr.left;
	    } else {
		curr = curr.right;
	    }
	}
	return false;
    }

    @Override
    public boolean equals(Bag<E> that) {

	// Check if they're the same size cannot be equal if not
	if (this.count != that.size()) {
	    return false;
	}
	Bag<E> copy = new BSTBag<E>();
	for (E item : that) {
	    copy.add(item);
	}

	// Check for equality by attempting to remove the item from the copy of
	// the other bag
	try {
	    for (E item : this) {
		copy.remove(item);
	    }
	} catch (NoSuchElementException nsee) {
	    return false;
	}
	return true;
    }

    // Set root to null and let the garbage collector handle the rest
    @Override
    public void clear() {
	root = null;
    }

    @Override
    public void add(E elem) {
	int direction = 0;
	Node<E> parent = null;
	Node<E> curr = root;
	for (;;) {
	    // Place of insertion must be null and check for the possible cases
	    if (curr == null) {
		Node<E> ins = new Node<E>(elem);
		if (root == null) {
		    root = ins;
		} else if (direction < 0) {
		    parent.left = ins;
		} else {
		    parent.right = ins;
		}
		count++;
		return;
	    }
	    // Decide if node needs to be inserted to the left or right by
	    // comparing the CountedElement usually str
	    direction = elem.compareTo(curr.element.getElement());
	    if (direction == 0) {
		curr.element.incrementCount();
		count++;
		return;
	    }
	    // Point of insertion is beyond the root determine direction to go
	    parent = curr;
	    if (direction < 0) {
		curr = curr.left;
	    } else {
		curr = curr.right;
	    }
	}
    }

    @Override
    public void remove(E elem) {
	// Check if the element exists within the tree
	if (!contains(elem)) {
	    throw new NoSuchElementException();
	}
	int direction = 0;
	Node<E> parent = null;
	Node<E> curr = root;
	for (;;) {
	    if (curr == null) {
		return;
	    }
	    direction = elem.compareTo(curr.element.getElement());
	    if (direction == 0) {
		curr.element.decrementCount();
		count--;
	    }
	    parent = curr;
	    if (direction < 0) {
		curr = curr.left;
	    } else {
		curr = curr.right;
	    }
	}
    }

    @Override
    public String toString() {
	StringBuilder sb = new StringBuilder();
	for (E item : this) {
	    sb.append(item + "\n");
	}
	return sb.toString();
    }

    @Override
    public Iterator<E> iterator() {
	return new InOrderIterator();
    }

    private class InOrderIterator implements Iterator<E> {
	// Iterator implemented as two stacks
	private Stack<Node<E>> track1;
	private Stack<Node<E>> track2;

	private InOrderIterator() {
	    track1 = new LinkedStack<Node<E>>();
	    track2 = new LinkedStack<Node<E>>();

	    // push the left side of the tree on one track
	    for (Node<E> curr = root; curr != null; curr = curr.left) {
		track1.push(curr);
	    }

	    // Add all unique elements onto the second track
	    while (!track1.empty()) {
		Node<E> place = track1.pop();
		for (Node<E> curr = place.right; curr != null; curr = curr.left) {
		    track1.push(curr);
		}
		track2.push(place);
	    }

	    // Add extra references to the same object depending on the counts
	    // on track1
	    while (!track2.empty()) {
		Node<E> place = track2.pop();
		for (int i = place.element.getCount(); i > 0; i--) {
		    track1.push(place);
		}
	    }
	}

	@Override
	public boolean hasNext() {
	    return !track1.empty();
	}

	@Override
	public E next() {
	    if (track1.empty())
		throw new NoSuchElementException();
	    Node<E> place = track1.pop();
	    return place.element.getElement();
	}
    }

}
