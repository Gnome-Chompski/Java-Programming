//Dante Preda 2346605

public class CountedElement<E extends Comparable<E>> implements Comparable<CountedElement<E>> {
    private E element;
    private int count;

    public CountedElement(E e, int count) {
	this.element = e;
	this.count = count;
    }

    public CountedElement(E e) {
	this.element = e;
	this.count = 1;
    }

    public E getElement() {
	return element;
    }

    public void setElement(E element) {
	this.element = element;
    }

    public int getCount() {
	return count;
    }

    public void setCount(int count) {
	this.count = count;
    }

    public void incrementCount() {
	this.count++;
    }

    public void decrementCount() {
	if (count > 0) {
	    this.count--;
	}
    }

    public String toString() {
	return "(" + element + ", " + count + ")";
    }

    public int compareTo(CountedElement<E> sC1) {

	if (this.element.equals(sC1.getElement())) {
	    if (this.count == sC1.getCount()) {
		return 0;
	    } else if (this.count < sC1.getCount()) {
		return -1;
	    } else {
		return 1;
	    }
	} else if (this.element.compareTo(sC1.getElement()) < 0) {
	    return -1;
	} else {
	    return 1;
	}
    }

}
