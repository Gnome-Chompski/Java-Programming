import java.io.FileNotFoundException;
import java.io.FileReader;
import java.util.Scanner;

public class WordProcessor2 {

    public static void main(String[] args) {

	Bag<String> bag = new BSTBag<String>();
	Bag<String> bag2 = new BSTBag<String>();

	Scanner sc;
	FileReader fr = null;
	try {
	    fr = new FileReader("file1.txt");
	    sc = new Scanner(fr);
	} catch (FileNotFoundException e) {
	    e.printStackTrace();
	} finally {
	    sc = new Scanner(fr);
	}
	while (sc.hasNext()) {
	    String word = sc.next();
	    bag.add(word);
	    bag2.add(word);
	}

	sc.close();

	System.out.println(bag);
    }
}
