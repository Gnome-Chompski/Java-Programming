import java.awt.*;

import javax.swing.JOptionPane;

public class AssEx1 {

	public static void main(String[] args) {
	    
//	    Wine redWine = new Wine("Merlot", 4, 3.65);
//	    CustomerAccount bob = new CustomerAccount("Bob", 10);
//	    
//	    double cost = bob.proccessSale(redWine.getQuantity(), redWine.getPrice());
//	    System.out.println(bob.getBalance() + " is the balance. Cost is " + cost);
	    
		String name ="Donte P";
		double balance=0;
		try {
			name = JOptionPane.showInputDialog(null, "Please enter your name");
		    if (name.equals("")){
			System.exit(0);
		    }
		    
		    boolean result = true;
		    balance=0;
		    while(result){
			try{
			    String balanceS = JOptionPane.showInputDialog(null, "Please enter balance owed");
			    balance = Double.parseDouble(balanceS.trim());
			    result = false;
			} catch(NumberFormatException e){
			    JOptionPane.showMessageDialog(null, "Please enter a valid balance", "Error", JOptionPane.ERROR_MESSAGE);
				}
		    }
	    } catch (NullPointerException e) {
	    	System.exit(0);
	    }
	    
	    
	    
	    System.out.println(name + balance);
	    LWMGUI kappa = new LWMGUI(new CustomerAccount(name, balance));
	    kappa.setVisible(true);
	}
}
