
public class CustomerAccount {
    
    private String name;
    private double balance;
    
    public CustomerAccount(String name, double balance){
		this.name = name;
		this.balance = balance;
    }
    
    public String proccessSale(int numBottles, double costBottle){
		double transaction = (double) (Math.round(numBottles * costBottle * 100)/100.0);
		balance += transaction;
		return String.format("%04.2f", transaction);
    }
    
    public String proccessReturn(int numBottles, double costBottle){
		double transaction = (double) (Math.round(numBottles * costBottle * 0.8 * 100)/100.0);
		balance -= transaction;
		return String.format("%04.2f", transaction);
    }

    public String getName() {
        return name;
    }

    public double getBalance() {
    	balance = (Math.round(balance*100))/100.0;
        return balance;
    }
    
    public String isBalanceNegative() {
    	if (balance < 0) {
    		return (String.format("%04.2f", (this.getBalance()*-1)) + " CR");
    	} else {
    		return String.format("%04.2f", this.getBalance());
    	}
    }
}
