import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class LWMGUI extends JFrame implements ActionListener{

	private JButton sale;
	private JButton ret;
	private JTextField name;
	private JTextField quant;
	private JTextField price;
	private JTextField trans;
	private JTextField bal;
	private JLabel nameL;
	private JLabel quantL;
	private JLabel priceL;
	private JLabel wineL;
	private JLabel transL;
	private JLabel balL;
	private JPanel bl1 = new JPanel();
	private JPanel gln = new JPanel();
	private JPanel flc = new JPanel();
	private JPanel gls = new JPanel();
	private CustomerAccount customer;
	
	public LWMGUI(CustomerAccount customer) {
	    this.customer = customer;
	    setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	    setTitle("Lilybank Wine Merchants: " + customer.getName());
	    LayoutControl();
	}
	
	private void LayoutControl() {
	    setSize(650,200);
		setLocation(600,300);
		
		
		bl1.setLayout(new BorderLayout());
		
		sale = new JButton("Process Sale");
		ret = new JButton("Process Return");
		sale.addActionListener(this);
		ret.addActionListener(this);
		
		name = new JTextField(7);
		quant = new JTextField(7);
		price = new JTextField(7);
		
		trans = new JTextField(2);
		bal = new JTextField(2);
		trans.setEnabled(false);
		bal.setEnabled(false);
		bal.setText(customer.isBalanceNegative());
		
//		if (customer.getBalance() < 0) {
//			bal.setText(String.format("%04.2f", (customer.getBalance()*-1)) + " CR");
//		} else {
//			bal.setText(String.format("%04.2f", customer.getBalance()));
//		}
		
		
		nameL = new JLabel("Name: ");
		quantL = new JLabel("Quantity: ");
		priceL = new JLabel("Price: �");
		wineL = new JLabel("Wine type: ");
		transL = new JLabel("Amount of Transaction: �");
		balL = new JLabel ("Current Balance: �");

		gln.setLayout(new GridLayout(1,6,10,10));
		gls.setLayout(new GridLayout(1,4,10,10));
		
		gln.add(nameL);
		gln.add(name);
		gln.add(quantL);
		gln.add(quant);
		gln.add(priceL);
		gln.add(price);
		bl1.add(gln, BorderLayout.NORTH);

		flc.add(sale);
		flc.add(ret);
		flc.add(wineL);
		bl1.add(flc, BorderLayout.CENTER);
		
		
		gls.add(transL);
		gls.add(trans);
		gls.add(balL);
		gls.add(bal);
		bl1.add(gls, BorderLayout.SOUTH);
		
		this.add(bl1);
	}
	
	public void actionPerformed(ActionEvent e){
	    if (e.getSource() == sale){
	    	saleButtonPressed();
	    } else if (e.getSource() == ret){
	    	returnButtonPressed();
	    }
	}
	
	private void saleButtonPressed(){
		try {
			Wine wine = new Wine(name.getText(), Integer.parseInt(quant.getText()), Double.parseDouble(price.getText()));
			String transaction = customer.proccessSale(wine.getQuantity(), wine.getPrice());
			trans.setText(transaction);
			bal.setText(customer.isBalanceNegative());
			wineL.setText("Wine type: " + wine.getName());
			clearTextFields();
		} catch (NumberFormatException e) {
			JOptionPane.showMessageDialog(null, "Please enter valid values for the wine name, quantity and/or price", "Error", JOptionPane.ERROR_MESSAGE);
		}
		
	}
	
	private void returnButtonPressed() {
		try {
			Wine wine = new Wine(name.getText(), Integer.parseInt(quant.getText()), Double.parseDouble(price.getText()));
			String transaction = customer.proccessReturn(wine.getQuantity(), wine.getPrice());
			trans.setText("" + transaction);
			bal.setText(customer.isBalanceNegative());
			wineL.setText("Wine type: " + wine.getName());
			clearTextFields();
		} catch (NumberFormatException e) {
			JOptionPane.showMessageDialog(null, "Please enter valid values for the wine name, quantity and/or price", "Error", JOptionPane.ERROR_MESSAGE);
		}
	}
	
	private void clearTextFields() {
		name.setText("");
		quant.setText("");
		price.setText("");
	}
}
