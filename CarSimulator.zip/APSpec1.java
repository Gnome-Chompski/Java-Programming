
public class APSpec1 {

    public static void main(String[] args) {
	
	final int rows = 10;
	final int cols = 20;
	final int spawnDelay = 1000;
	
	JunctionGrid jg = new JunctionGrid(rows, cols);
	Thread grid = new Thread(jg);
	
	VehicleGenerator northSouthCars = new NSCarGenerator(rows, cols, spawnDelay, jg);
	VehicleGenerator westEastCars = new WECarGenerator(rows, cols, spawnDelay, jg);
	
	jg.addGenerator(northSouthCars);
	jg.addGenerator(westEastCars);
	
	grid.start();
	
	try {
	    grid.join();
	} catch (InterruptedException e) {
	    e.printStackTrace();
	} finally {
	    System.exit(0);
	}
	
    }

}
