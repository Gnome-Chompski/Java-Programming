
public class APSpec2 {

    public static void main(String[] args) {

	final int rows = 10;
	final int cols = 20;
	final int spawnDelay = 1000;
	
	JunctionGrid jg = new JunctionGrid(rows, cols);
	Thread grid = new Thread(jg);
	jg.setFrames(1000); //How many times the grid is to be drawn
	VehicleGenerator northSouthCars = new NSCarGenerator(rows, cols, spawnDelay, jg);
	VehicleGenerator westEastCars = new WECarGenerator(rows, cols, spawnDelay, jg);
	
	//Enable cars to go both ways
	northSouthCars.setSingleLane(false);
	westEastCars.setSingleLane(false);
	
	//Add generator to the grid once the grid ends, generator threads are interrupted
	jg.addGenerator(northSouthCars);
	jg.addGenerator(westEastCars);

	grid.start();
	
	try {
	    grid.join();
	} catch (InterruptedException e) {
	    e.printStackTrace();
	} finally {
	    Statistics stats = new Statistics();
	    stats.statsToConsole();
	    System.exit(0);
	}
	
    }

}
