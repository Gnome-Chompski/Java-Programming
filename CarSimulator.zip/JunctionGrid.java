import java.util.ArrayList;
import java.util.Collections;
import java.util.concurrent.locks.Condition;
import java.util.concurrent.locks.ReentrantLock;
/**
 * JunctionGrid class creates a 2D array of Vehicles, as it models a real world junction
 * vehicles that exists on their own threads can traverse the grid in accordance to their own
 * movement strategy. The grid exists on its own thread and can exist for certain number of frames.
 * The default number of frames is 2000 but can be changed prior to starting the thread.
 * */
public class JunctionGrid implements Runnable {

    private Vehicle[][] grid;
    private int frames;
    private final ReentrantLock lock = new ReentrantLock();
    private final Condition isOccupied = lock.newCondition();
    private ArrayList<Thread> generators;
    
    /**
     * Class constructor takes in parameters for the size of the grid.
     * 
     * @param rows - integer corresponding to the number of rows in the grid
     * @param cols - integer corresponding to the number of columns in the grid
     * */
    public JunctionGrid(int rows, int cols) {
	this.grid = new Vehicle[rows][cols];
	generators = new ArrayList<Thread>();
	frames = 2000;
    }
    
    /**
     * Method to add a vehicle at a specified location on the grid. Once assigned to the grid
     * the vehicle thread starts executing.
     * 
     * @param x - integer corresponding to the row
     * @param y - integer corresponding to the column
     * @param car - vehicle to be added to grid
     * */
    public synchronized void addCar(int x, int y, Vehicle car) {
	this.grid[x][y] = car;
	car.setX(x);
	car.setY(y);
	Statistics.incrementCars();
	car.start();
    }
    
    /**
     * Method updates the vehicles position within the grid. As each vehicle within its own thread
     * only one can modify the grid at any one time enforced by a conditional lock. If the target area
     * a vehicle moves into is occupied it will enter an await state. If the target is outside the grid
     * the thread terminates as it will be moving outside the grid. If the position is not empty the car
     * will move into the new position leaving the old one empty.
     * 
     * @param car - Vehicle that is moving in the grid
     * */
    public void updatePosition(Vehicle car) {	
	lock.lock();
	int[] target = car.target();
	
	if (target[0] >= grid.length || target[0] < 0 || target[1] >= grid[0].length || target[1] < 0) {
	    car.endTime();
	    car.interrupt();
	    grid[car.getX()][car.getY()] = null;
	    Statistics.incrementFinishedCars();
	} else {
	    while (!isEmpty(target[0], target[1])) {
		    try {
			isOccupied.await();
		    } catch (InterruptedException e) {
			e.printStackTrace();
		    }
		}
	    grid[car.getX()][car.getY()] = null;
	    car.move();
	    grid[car.getX()][car.getY()] = car;
	}
	
	isOccupied.signalAll();
	lock.unlock();
    }

    /**
     * Code to be executed when thread is running. Each generator that has been set for this
     * grid is started. The grid is printed the desired number of times with 100ms between each frame.
     * When complete the generator threads are interrupted.
     * */
    @Override
    public void run() {
	
	for (Thread t: generators){
	    t.start();
	}
	
	for (int i = 0; i < frames; i++) {
	    System.out.println(this);
	    try {
		Thread.sleep(20);
	    } catch (InterruptedException e) {
		e.printStackTrace();
	    } 
	}
	
	for (Thread t: generators){
	    t.interrupt();
	}
    }
    
    /**
     * Check if a position on the grid is empty
     * 
     * @param x - row position
     * @param y - column position
     * @return true - if specified position is empty
     * @return false - if specified position is occupied
     * */
    public synchronized boolean isEmpty(int x, int y) {
	if (grid[x][y] == null) {
	    return true;
	} else {
	    return false;
	}
    }
    
    /**
     * Method to create a string representation of the grid and various occupancies within it
     * 
     * @return string - representation of JunctionGrid as a string
     * */
    
    public String toString() {
	StringBuilder gridPrint = new StringBuilder();
	String header = String.join("", Collections.nCopies((grid[0].length * 2) + 1, "-"));
	gridPrint.append(header + "\n");
	for (int i = 0; i < grid.length; i++){
	    gridPrint.append("|");
	    for (int j = 0; j < grid[0].length; j++) {
		if (grid[i][j] == null) {
		    gridPrint.append(" |");
		} else {
		    gridPrint.append(grid[i][j].toString() + "|");
		}
	    }
	    gridPrint.append("\n");
	}
	gridPrint.append(header);
	return gridPrint.toString();
    }
    
    
    /**
     * Adds a generator to operate on this grid. If no generators added the grid will be empty.
     * */
    public void addGenerator(VehicleGenerator vg) {
	generators.add(new Thread(vg));
    }
    
    public void setFrames(int frames) {
	this.frames = frames;
    }
}
