/**
 * NSCar extends Vehicle class and it models the behaviour of a vehicle traveling north-south or
 * vice-versa. Each vehicle runs on its own thread.
 * */
public class NSCar extends Vehicle{

    /**
     * Constructor for NSCar.
     * 
     * @param grid - JunctionGrid car will be running on
     * @param speed - the period of time the car will wait before attempting to move in the next position
     * @param direction - can be any integer apart from zero only sign matters, negative makes the cars
     * move from top to bottom, positive it is bottom to top 
     * */
    public NSCar(JunctionGrid grid, int speed, int direction) {
	super(grid, speed, direction);
    }

    /**
     * Code to be executing during thread runtime. Sets the start time of when it starts and calls the update
     * position method from the grid. Once off the grid the thread will be interrupted.
     * */
    @Override
    public void run() {
	setStartTime(System.nanoTime());
	try {
	    while (true){
		grid.updatePosition(this);
		sleep(speed);
	    }
	} catch (InterruptedException ie) {
	    
	} 
    }
    
    /**
     * String representation of the vehicle on the grid.
     * 
     * @returns string - how the car looks on the grid
     * */
    public String toString() {
	return "o";
    }

    /**
     * Movement strategy for this particular vehicle, it increments/decrements the row position by 1 depending
     * on the sign of the direction. The location is stored within the vehicle.
     * */
    @Override
    public void move() {
	setX(getX() + (1 * getDirection()));
    }

    /**
     * Similar to movement but rather than mutating the position it provides a snapshot of the next location the 
     * car will move towards.
     * 
     * @return coordinates - array of integers containing row and column number respectively
     * */
    @Override
    public int[] target() {
	int[] coordinates = new int[2];
	coordinates[0] = getX() + (1 * getDirection());
	coordinates[1] = getY();
	return coordinates;
    }

    /**
     * Method that calculates the time taken for the thread to run and is recorded to the statistics class.
     * */
    public void endTime() {
	long time = System.nanoTime() - getStartTime();
	Statistics.addToNS(time);
    }
}
