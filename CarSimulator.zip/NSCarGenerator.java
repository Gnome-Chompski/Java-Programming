/**
 * Generator class that exclusively produces NSCars.
 * */
public class NSCarGenerator extends VehicleGenerator {
    
    /**
     * Constructor for NSCarGenerator similar to constructor from superclass.
     * */
    public NSCarGenerator(int rows, int columns, int spawnRate, JunctionGrid grid) {
	super(rows, columns, spawnRate, grid);
    }

    /**
     * Method to be executed while running on a thread. It runs while the grid is active and is interrupted when
     * grid stops execution. It generators positions for two cars at a time
     * */
    @Override
    public void run() {

	try {
	    JunctionGrid grid = getGrid();

	    while (true) {
		int y = randomInt(0, getColumns());
		int speed = randomInt(100, 1000);
		if (isSingleLane() && grid.isEmpty(0, y)) {
		    grid.addCar(0, y, new NSCar(grid, speed, -1));
		} else if (!isSingleLane() && (y < getColumns()/2) && grid.isEmpty(0, y)) {
		    grid.addCar(0, y, new NSCar(grid, speed, -1));
		} else if (!isSingleLane() && (y >= getColumns()/2) && grid.isEmpty((getRows() -1), y)) {
		    grid.addCar((getRows() -1), y, new NSCar(grid, speed, 3));
		}
		Thread.sleep(getSpawnRate());
	    }
	    
	} catch (InterruptedException e) {
	    
	}
    }

}
