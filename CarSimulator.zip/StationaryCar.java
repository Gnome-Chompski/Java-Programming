/**
 * Stationary car extends the vehicle class. The sole purpose of this class is for testing the locks
 * and checking that the conditions work within the grid. Also useful for locking down certain parts of the grid.
 * */
public class StationaryCar extends Vehicle{

    public StationaryCar(JunctionGrid grid, int speed, int direction) {
	super(grid, speed, direction);
    }

    @Override
    public void run() {
	while (true){
	    try {
		Thread.sleep(speed);
	    } catch (InterruptedException e) {
		e.printStackTrace();
	    }
	}
    }

    @Override
    public void move() {}

    @Override
    public int[] target() {
	return null;
    }
    
    @Override
    public String toString() {
	return "X";
    }

    @Override
    public void endTime() {
	
    }

}
