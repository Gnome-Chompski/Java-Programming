import java.util.ArrayList;

public class Statistics {

    private static ArrayList<Long> northSouthStatistics = new ArrayList<Long>();
    private static ArrayList<Long> westEastStatistics = new ArrayList<Long>();
    private static int numberOfCars = 0;
    private static int finishedCars = 0;
    
    /**
     * Empty constructor as all instance variables are static.
     * */
    public Statistics() {}
    
    /**
     * Adds a time corresponding to a specific generator. The method needs to be synchronized as multiple threads will
     * be accessing this list. Corresponds to the times spent by cars traveling north and south.
     * */
    public static synchronized void addToNS(long time) {
	northSouthStatistics.add(time);
    }
    
    /**
     * Adds a time corresponding to a specific generator. The method needs to be synchronized as multiple threads will
     * be accessing this list. Corresponds to the times spent by cars traveling west and east.
     * */
    public static synchronized void addToWE(long time) {
	westEastStatistics.add(time);
    }
    
    /**
     * Increment the number of created cars
     * */
    public static synchronized void incrementCars() {
	numberOfCars++;
    }
    
    /**
     * Increment the number of cars that have left the grid
     * */
    public static synchronized void incrementFinishedCars() {
	finishedCars++;
    }
    
    /**
     * Calculates the mean within a list of times in ns.
     * 
     * @param list - list of times to find the mean of
     * @return mean - average time within the list
     * */
    private long calculateMean(ArrayList<Long> list) {
	long sum = 0;
	for (Long item: list) {
	    sum += item;
	}
	return sum/list.size();
    }
    
    /**
     * Finds and returns the smallest value within the list.
     * 
     * @param list - the list to search
     * @returns min - the shortest time within the list
     * */
    private long findMin(ArrayList<Long> list){
	long min = list.get(0);
	for (Long item: list) {
	    if (item < min) {
		min = item;
	    }
	}
	return min;
    }
    
    /**
     * Finds and returns the largest value within the list.
     * 
     * @param list - the list to search
     * @returns max - the shortest time within the list
     * */
    private long findMax(ArrayList<Long> list){
	long max = list.get(0);
	for (Long item: list) {
	    if (item > max) {
		max = item;
	    }
	}
	return max;
    }
    
    /**
     * Calculates the variance within the list.
     * 
     * @param list - list of times
     * @return variance of times
     * */
    private long calculateVariance(ArrayList<Long> list) {
	long mean = calculateMean(list);
	long sum = 0;
	for (Long item: list) {
	    long ting = item - mean;
	    sum += Math.pow((ting), 2);
	}
	long variance = sum/list.size();
	return (long) Math.sqrt(variance);
    }
    
    /**
     * All values are calculated in ns method converts from ns to ms.
     * 
     * @param num - long a time in nanoseconds
     * @return num - long a time in milliseconds rounded.
     * */
    private long convertToMillis(long num){
	double number = (double) num;
	number /= Math.pow(10, 6);
	return (long) Math.round(number);
    }
    
    public void statsToConsole() {
	System.err.println("Total number of cars created: " + numberOfCars);
	System.err.println("Total number of cars that have left the grid: " + finishedCars);
	if (northSouthStatistics.size() > 0) {
	    System.err.println("NS Generator Statistics");
	    System.err.println("Mean: " + convertToMillis(calculateMean(northSouthStatistics)));
	    System.err.println("Smallest Value: " + convertToMillis(findMin(northSouthStatistics)));
	    System.err.println("Largest Value: " + convertToMillis(findMax(northSouthStatistics)));
	    System.err.println("Variance: " + convertToMillis(calculateVariance(northSouthStatistics)));
	} else {
	    System.err.println("No NS statistics present");
	}
	if (westEastStatistics.size() > 0){
	    System.err.println("\nWE Generator Statistics");
	    System.err.println("Mean: " + convertToMillis(calculateMean(westEastStatistics)));
	    System.err.println("Smallest Value: " + convertToMillis(findMin(westEastStatistics)));
	    System.err.println("Largest Value: " + convertToMillis(findMax(westEastStatistics)));
	    System.err.println("Variance: " + convertToMillis(calculateVariance(westEastStatistics)));
	} else {
	    System.err.println("No WE statistics present");
	}	
    }
}
