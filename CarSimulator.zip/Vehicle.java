/**
 * Vehicle class used as a general framework for constructing vehicles. Each holds information about its
 * position, speed, direction and the grid it is driving on. Movement strategies are defined in subclasses
 * but generally only supports 2 dimensional movement.
 * */
public abstract class Vehicle extends Thread {

    protected int speed;
    private int x;
    private int y;
    private int direction;
    protected JunctionGrid grid;
    private long startTime;
    
    /**
     * Construction that initialises all instance variables. Position is set when the vehicle is added
     * to a grid. Direction is adjusted to correspond to either 1 or -1. Cases where one might input 0 are handled
     * but it is assumed that numbers which do not cause overflow will be used.
     * 
     * @param grid - JunctionGrid for the vehicle to run on
     * @param speed - Misnomer speed represents the time in ms the thread halts execution before attempting to move in a new spot
     * @param direction - any int, sign is the only relevant factor in deciding which direction the vehicle moves
     * */
    public Vehicle (JunctionGrid grid, int speed, int direction){
	this.grid = grid;
	this.speed = speed;
	try {
	    this.direction = (direction/(Math.abs(direction) * -1));
	} catch (ArithmeticException ae) {
	    System.err.println("Cannot have a 0 direction, use positive or negative numbers when making cars");
	}
	
    }
    
    public abstract void move();
    public abstract int[] target();
    public abstract void endTime();

    public int getX() {
        return x;
    }

    public void setX(int x) {
        this.x = x;
    }

    public int getY() {
        return y;
    }

    public void setY(int y) {
        this.y = y;
    }

    public int getDirection() {
        return direction;
    }

    public void setDirection(int direction) {
        this.direction = direction;
    }

    public long getStartTime() {
        return startTime;
    }

    public void setStartTime(long startTime) {
        this.startTime = startTime;
    }
    
    
}
