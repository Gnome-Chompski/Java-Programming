import java.util.Random;

/**
 * Vehicle generators are responsible for creating vehicles and adding them to a specific grid. This is a general class
 * as inheriting generators will correspond to specific car type. Generators can be created to accommodate other kinds of vehicles.
 * */
public abstract class VehicleGenerator implements Runnable {

    private int columns;
    private int rows;
    private int spawnRate;
    private boolean singleLane;
    private JunctionGrid grid;
    private Random rand;
    
    /**
     * Constructor for the generator. Singlelane signifies a one way junction if set to false it will model an intersection
     * with lanes going both ways.
     * 
     * @param rows - number of rows for which it should generate from 0
     * @param columsn - number of columns for which it should generate from 0
     * @param spawnRate - time to wait for creating a new pair of vehicles
     * @param grid - which JunctionGrid the cars should be printed to
     * */
    public VehicleGenerator(int rows, int columns, int spawnRate, JunctionGrid grid) {
	this.rows = rows;
	this.columns = columns;
	this.spawnRate = spawnRate;
	this.grid = grid;
	rand = new Random();
	singleLane = true;
    }
    
    /**
     * Returns a random integer within the specified range
     * */
    public int randomInt(int lowerbound, int upperbound) {
	return rand.nextInt((upperbound - lowerbound)) + lowerbound;
    }

    public int getColumns() {
        return columns;
    }

    public void setColumns(int columns) {
        this.columns = columns;
    }

    public int getRows() {
        return rows;
    }

    public void setRows(int rows) {
        this.rows = rows;
    }

    public int getSpawnRate() {
        return spawnRate;
    }

    public void setSpawnRate(int spawnRate) {
        this.spawnRate = spawnRate;
    }

    public JunctionGrid getGrid() {
        return grid;
    }

    public boolean isSingleLane() {
        return singleLane;
    }

    public void setSingleLane(boolean singleLane) {
        this.singleLane = singleLane;
    }
}
