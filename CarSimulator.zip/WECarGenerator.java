
public class WECarGenerator extends VehicleGenerator {

    public WECarGenerator(int rows, int columns, int spawnRate, JunctionGrid grid) {
	super(rows, columns, spawnRate, grid);
    }

    @Override
    public void run() {

	try {
	    JunctionGrid grid = getGrid();

	    while (true) {
		int x = randomInt(0, getRows());
		int speed = randomInt(100, 1000);
		if (isSingleLane() && grid.isEmpty(x, 0)) {
		    grid.addCar(x, 0, new WECar(grid, speed, -1));
		} else if (!isSingleLane() && (x < getRows()/2) && grid.isEmpty(x, 0)) {
		    grid.addCar(x, 0, new WECar(grid, speed, -1));
		} else if (!isSingleLane() && (x >= getRows()/2) && grid.isEmpty(x, (getColumns() -1))) {
		    grid.addCar(x, (getColumns() -1), new WECar(grid, speed, 3));
		}
		Thread.sleep(getSpawnRate());
	    }
	    
	} catch (InterruptedException e) {
	    
	}
    }
}

