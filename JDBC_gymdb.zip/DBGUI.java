import java.awt.event.*;
import java.awt.*;
import javax.swing.*;

public class DBGUI extends JFrame implements ActionListener, WindowListener {

	private DataBaseConnector dbc; // Declare a DataBaseConnector object to tie GUI to database
	private JPanel mainP, bookP, tableP, buttonP;
	private JButton courseButton, bookButton, deleteButton, selectCourse, mainButton;
	private JLabel idLabel, courseLabel;
	private JTextField idField, courseField;
	private String[] courseList;
	private JComboBox courses;
	private JTable table;
	private JScrollPane sp;
	private int numberBookings;
	private final int BOOKING_LIMIT = 40; // Limits on bookings is handled by GUI

	/*
	 * Class constructor for DBGUI creates DataBaseConnector object and generates
	 * necessary GUI
	 */
	public DBGUI() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		dbc = new DataBaseConnector("m_17_2346605p", "m_17_2346605p", "2346605p");
		LayoutControl();
		numberBookings = dbc.rowCounter("bookings");
		this.addWindowListener(this);
	}

	/*
	 * Solely exists for the constructor, handles layout of widgets Borderlayout was
	 * chosen for this GUI
	 */
	private void LayoutControl() {
		setSize(650, 200);
		setLocation(600, 300);
		setTitle("Gym Database");

		mainP = new JPanel();
		mainP.setLayout(new BorderLayout());

		bookP = new JPanel();

		idLabel = new JLabel("Enter ID: ");
		courseLabel = new JLabel("Enter course name: ");
		idField = new JTextField(7);
		courseField = new JTextField(7);
		bookButton = new JButton("Book course");
		bookButton.addActionListener(this);
		deleteButton = new JButton("Delete booking");
		deleteButton.addActionListener(this);
		bookP.add(idLabel);
		bookP.add(idField);
		bookP.add(courseLabel);
		bookP.add(courseField);
		bookP.add(bookButton);

		bookP.add(deleteButton);

		mainP.add(bookP, BorderLayout.NORTH);

		tableP = new JPanel();
		mainButton = new JButton("View all available courses");
		mainButton.addActionListener(this);
		tableP.add(mainButton);
		mainP.add(tableP, BorderLayout.CENTER);

		buttonP = new JPanel();

		courseButton = new JButton("View all bookings");
		courseButton.addActionListener(this);
		courseList = dbc.courseList();
		courses = new JComboBox(courseList);
		selectCourse = new JButton("View bookings");
		selectCourse.addActionListener(this);
		buttonP.add(courseButton);
		buttonP.add(courses);
		buttonP.add(selectCourse);

		mainP.add(buttonP, BorderLayout.SOUTH);

		this.add(mainP);
	}

	/*
	 * Handles button presses by the user corresponding functions are executed
	 */
	public void actionPerformed(ActionEvent e) {
		if (e.getSource() == bookButton) {
			bookButtonPressed();
		} else if (e.getSource() == deleteButton) {
			deleteButtonPressed();
		} else if (e.getSource() == courseButton) {
			courseButtonPressed();
		} else if (e.getSource() == selectCourse) {
			selectCoursePressed();
		} else if (e.getSource() == mainButton) {
			mainButtonPressed();
		}
	}

	/*
	 * Allows user to add a booking if there is space available textfields are
	 * cleared
	 */
	public void bookButtonPressed() {
		if (numberBookings < BOOKING_LIMIT) {
			dbc.makeBooking(courseField.getText(), idField.getText());
			numberBookings++;
		} else {
			JOptionPane.showMessageDialog(null, "Booking Limit Reached, please delete bookings", "Error",
					JOptionPane.ERROR_MESSAGE);
		}
		courseField.setText("");
		idField.setText("");
	}

	/*
	 * Allows the user to delete an existing booking from the database
	 */
	public void deleteButtonPressed() {
		if (numberBookings > 0) {
			dbc.deleteBooking(courseField.getText(), idField.getText());
			numberBookings--;
		} else {
			JOptionPane.showMessageDialog(null, "No bookings to delete", "Error", JOptionPane.ERROR_MESSAGE);
		}
		courseField.setText("");
		idField.setText("");
	}

	/*
	 * Creates a new window to display the results held within the DataBaseConnector
	 * in a new window Displays all the members currently booked on a course
	 */
	public void courseButtonPressed() {
		dbc.viewCourseBookings();
		String[] col = { "Full Name", "ID number", "Course" };
		createNewWindow(dbc.getResults(), col);
	}

	/*
	 * Creates a new window to display the results held within the DataBaseConnector
	 * in a new window Displays all the members currently booked on a specific
	 * course determined by the JComboBox
	 */
	public void selectCoursePressed() {
		dbc.viewCourseBookings((String) courses.getSelectedItem());
		String[] col = { "Full Name", "ID number", "Course" };
		createNewWindow(dbc.getResults(), col);
	}

	/*
	 * Creates a new window to display the results held within the DataBaseConnector
	 * in a new window Displays all the courses available, instructor, capacity and
	 * how full they are
	 */
	public void mainButtonPressed() {
		dbc.viewCourses();
		String[] col = { "Course", "Instructor", "Capacity", "No. Booked" };
		createNewWindow(dbc.getResults(), col);
	}

	/*
	 * Creates a new window to display the tables of data resulting from the
	 * relevant SQL queries. User can close windows without terminating the program
	 * 
	 * @param rows, main table data
	 * 
	 * @param col, headers of column
	 */
	public void createNewWindow(String[][] rows, String[] col) {
		JFrame window = new JFrame("Table of Information");
		window.setVisible(true);
		window.setSize(650, 200);
		window.setLocation(800, 200);
		window.setDefaultCloseOperation(DISPOSE_ON_CLOSE);
		JPanel component = new JPanel();
		JTable table = new JTable(rows, col);
		JScrollPane sp = new JScrollPane(table);
		component.add(sp);
		window.add(component);

	}

	public void windowActivated(WindowEvent e) {
	}

	public void windowClosed(WindowEvent e) {
	}

	// Ensures database connection is closed when user closes the main window
	public void windowClosing(WindowEvent e) {
		dbc.closeConnect();
		System.exit(0);
	}

	public void windowDeactivated(WindowEvent e) {
	}

	public void windowDeiconified(WindowEvent e) {
	}

	public void windowIconified(WindowEvent e) {
	}

	public void windowOpened(WindowEvent e) {
	}

}
