public class DTAAE1 {

	/*
	 * DTAAE1 holds the main method to instantiate the GUI that will handle all the
	 * necessary database operations
	 */

	public static void main(String[] args) {

		DBGUI gui = new DBGUI();
		gui.setVisible(true);

	}

}
