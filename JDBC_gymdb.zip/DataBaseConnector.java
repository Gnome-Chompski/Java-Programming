import java.sql.*;
import javax.swing.JOptionPane;

public class DataBaseConnector {

	private Connection connection = null;
	private String dbName, userName, passWord;
	private String[][] results; // holds data pertaining to SQL queries in 2D array

	/*
	 * DataBaseConnector constructor creates DataBaseConnector object which handles
	 * all the database operations
	 * 
	 * @param db, name of the database
	 * 
	 * @param us, username for the database
	 * 
	 * @param pas, password to access the database
	 */
	public DataBaseConnector(String db, String us, String pas) {
		dbName = db;
		userName = us;
		passWord = pas;
		connect();
	}

	// getter for results
	public String[][] getResults() {
		return results;
	}

	/*
	 * Establishes connection to database and is called once in constructor
	 */
	private void connect() {
		try {
			connection = DriverManager.getConnection("jdbc:postgresql://yacata.dcs.gla.ac.uk:5432/" + dbName, userName,
					passWord);
		} catch (SQLException e) {
			System.err.println("Connection Failed!");
			e.printStackTrace();
			return;
		}
		if (connection != null) {
			System.out.println("Connection successful");
		} else {
			System.err.println("Failed to make connection!");
		}

	}

	// Closes the currently open connection
	public void closeConnect() {
		try {
			connection.close();
			System.out.println("Connection closed");
		} catch (SQLException e) {
			e.printStackTrace();
			System.out.println("Connection could not be closed � SQLexception");
		}
	}

	/*
	 * Executes simple query where the expected result is to be single valued
	 * 
	 * @param query, SQL query as a string
	 * 
	 * @param col, attribute column that is of interest returns the first found by
	 * this method
	 */
	public String query(String query, String col) {
		Statement stmt = null;
		try {
			stmt = connection.createStatement();
			ResultSet rs = stmt.executeQuery(query);
			while (rs.next()) {
				return rs.getString(col);
			}
		} catch (SQLException e) {
			e.printStackTrace();
			System.err.println("error executing query " + query);
		}
		return "";
	}

	/*
	 * Method executes SQL query to find courses, instructors, their capacity and
	 * space filled Results are stored within the instance variable result 2D array
	 */
	public void viewCourses() {
		Statement stmt = null;
		try {
			results = new String[rowCounter("gymcourse")][4];
			String[] col = { "cname", "fname", "capacity", "bookings" };
			stmt = connection.createStatement();
			ResultSet rs = stmt.executeQuery(
					"SELECT gc.cname,gm.fname,gc.capacity,gc.bookings FROM gymcourse AS gc INNER JOIN gymmembers AS gm ON gc.instructorid = gm.memberid");
			int i = 0;
			int j = 0;
			while (rs.next()) {
				while (j < 4) {
					results[i][j] = rs.getString(col[j]);
					j++;
				}
				i++;
				if (j >= 3) {
					j = 0;
				}
			}
		} catch (SQLException e) {
			e.printStackTrace();
			System.err.println("error executing query ");
		}
	}

	/*
	 * Method queries the whole booking table with the names of the people taking
	 * the course via INNER JOIN Results are stored within the 2D array results
	 * instance variable
	 */
	public void viewCourseBookings() {
		Statement stmt = null;
		try {
			results = new String[rowCounter("bookings")][3];
			String[] col = { "fname", "memberid", "course" };
			stmt = connection.createStatement();
			ResultSet rs = stmt.executeQuery(
					"SELECT fname, gm.memberid, course FROM bookings AS b INNER JOIN gymmembers AS gm ON b.memberid = gm.memberid");
			int i = 0;
			int j = 0;
			while (rs.next()) {
				while (j < 3) {
					results[i][j] = rs.getString(col[j]);
					j++;
				}
				i++;
				if (j >= 2) {
					j = 0;
				}
			}
		} catch (SQLException e) {
			e.printStackTrace();
			System.err.println("error executing query ");
		}
	}

	/*
	 * Method returns a similar similar result as method above but the result is
	 * stored by a specific course
	 * 
	 * @param course, the desired to course to view bookings for
	 */
	public void viewCourseBookings(String course) {
		Statement stmt = null;
		try {
			results = new String[rowCounter("bookings")][3];
			String[] col = { "fname", "memberid", "course" };
			stmt = connection.createStatement();
			ResultSet rs = stmt.executeQuery(String.format(
					"SELECT fname, gm.memberid, course FROM bookings AS b INNER JOIN gymmembers AS gm ON b.memberid = gm.memberid WHERE course = '%s'",
					course));
			int i = 0;
			int j = 0;
			while (rs.next()) {
				while (j < 3) {
					results[i][j] = rs.getString(col[j]);
					j++;
				}
				i++;
				if (j >= 2) {
					j = 0;
				}
			}
		} catch (SQLException e) {
			e.printStackTrace();
			System.err.println("error executing query ");
		}
	}

	/*
	 * Performs a booking by updating the bookings table within the data,
	 * preliminary checks are made to not exceed the course capacity
	 * 
	 * @param course, name of the course to be booked onto
	 * 
	 * @param id, id of the member to be booked on the course
	 */
	public void makeBooking(String course, String id) {
		Statement stmt = null;
		try {
			stmt = connection.createStatement();
			// Check if id is valid else throw NumberFormatException
			if (query("SELECT fname FROM gymmembers WHERE memberid = " + id, "fname").equals("")) {
				throw new NumberFormatException();
			}
			// retrieve number of existing bookings
			String booking = query(String.format("SELECT bookings FROM gymcourse WHERE cname = '%s'", course),
					"bookings");
			int bookno = Integer.parseInt(booking);
			bookno += 1;
			// attempt to update bookings, cannot exceed max capacity
			int rs = stmt.executeUpdate(
					String.format("UPDATE gymcourse SET bookings = %d WHERE cname = '%s'", bookno, course));
			rs = stmt.executeUpdate(String.format("INSERT INTO bookings VALUES (%s,'%s')", id, course));
		} catch (SQLException e) {
			JOptionPane.showMessageDialog(null, "Incorrect Input, booking already exists or the class is already full",
					"Error", JOptionPane.ERROR_MESSAGE);
		} catch (NumberFormatException nfe) {
			JOptionPane.showMessageDialog(null, "Input does not exist in database", "Error", JOptionPane.ERROR_MESSAGE);
		}
	}

	/*
	 * Removes an existing booking from the database
	 * 
	 * @param course, name of course to be removed from
	 * 
	 * @param id, member id of person to be removed
	 */
	public void deleteBooking(String course, String id) {
		Statement stmt = null;
		try {
			stmt = connection.createStatement();
			int rs = stmt.executeUpdate(
					String.format("DELETE FROM bookings WHERE memberid = %s AND course = '%s'", id, course));
			// if nothing was deleted the existing tables don't need to be updated
			if (rs == 0) {
				throw new SQLException();
			}
			String booking = query(String.format("SELECT bookings FROM gymcourse WHERE cname = '%s'", course),
					"bookings");
			int bookno = Integer.parseInt(booking);
			bookno--;
			rs = stmt.executeUpdate(
					String.format("UPDATE gymcourse SET bookings = %d WHERE cname = '%s'", bookno, course));
		} catch (SQLException e) {
			JOptionPane.showMessageDialog(null, "Incorrect Input format or booking does not exist", "Error",
					JOptionPane.ERROR_MESSAGE);

		}
	}

	/*
	 * Counts the number of rows within a table
	 * 
	 * @param table, the table to count the rows of
	 */
	public int rowCounter(String table) {
		Statement stmt = null;
		try {
			stmt = connection.createStatement();
			ResultSet rs = stmt.executeQuery("SELECT COUNT(*) AS total FROM " + table);
			while (rs.next()) {
				return rs.getInt("total");
			}
		} catch (SQLException e) {
			e.printStackTrace();
			System.err.println("error executing query ");
		}
		return -1;
	}

	/*
	 * Generates a list of courses from the database, coursenames are unique Exists
	 * if additional courses are added to the database
	 */
	public String[] courseList() {
		Statement stmt = null;
		String[] courses = new String[rowCounter("gymcourse")];
		try {
			stmt = connection.createStatement();
			ResultSet rs = stmt.executeQuery("SELECT cname FROM gymcourse");
			int i = 0;
			while (rs.next()) {
				courses[i] = rs.getString("cname");
				i++;
			}
		} catch (SQLException e) {
			e.printStackTrace();
			System.err.println("error executing query ");
		}
		return courses;
	}

}
